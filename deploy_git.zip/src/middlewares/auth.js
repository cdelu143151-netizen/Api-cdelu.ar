/**
 * Middleware de autenticación
 * @param {Object} request - Objeto de solicitud Fastify
 * @param {Object} reply - Objeto de respuesta Fastify
 */
async function authenticate(request, reply) {
  try {
    const decoded = await request.jwtVerify();
    request.user = decoded;
  } catch (err) {
    return reply.status(401).send({ error: 'No autorizado' });
  }
}

/**
 * Middleware de autorización por rol
 * @param {string[]} roles - Roles permitidos
 */
function authorize(roles) {
  return async (request, reply) => {
    try {
      const userRole = request.user ? (request.user.rol || request.user.role) : undefined;
      if (!userRole) {
        return reply.status(401).send({ error: 'No autorizado' });
      }

      if (!roles.includes(userRole)) {
        return reply.status(403).send({ error: 'No tienes permiso para realizar esta acción' });
      }
    } catch (err) {
      return reply.status(401).send({ error: 'No autorizado' });
    }
  };
}

/**
 * Middleware de autenticación por API Key
 * @param {Object} request - Objeto de solicitud Fastify
 * @param {Object} reply - Objeto de respuesta Fastify
 */
async function authenticateApiKey(request, reply) {
  const config = require('../config/default');
  const apiKey = request.headers['x-api-key'] || request.headers['authorization']?.replace('Bearer ', '');

  if (!apiKey || apiKey !== config.apiKey) {
    return reply.status(401).send({ error: 'API Key inválida' });
  }
}

module.exports = {
  authenticate,
  authorize,
  authenticateApiKey
}; 