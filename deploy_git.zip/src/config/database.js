const mysql = require('mysql2/promise');
require('dotenv').config();

// Configuración de la conexión a la base de datos
const config = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT, 10) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'cdelu_diario',
  waitForConnections: true,
  connectionLimit: parseInt(process.env.DB_POOL_MAX, 10) || 5, // Reducido para hosting compartido
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000, // 10 segundos
  connectTimeout: 10000, // 10 segundos
  // Manejo de desconexiones
  timezone: 'Z', // Forzar zona horaria UTC para consistencia
  // dateStrings: true, // Removido para permitir que mysql2 maneje objetos Date y Fastify genere ISO strings
  // Opciones de seguridad
  supportBigNumbers: true,
  bigNumberStrings: true,
  // Configuración adicional para hosting compartido - remover opciones obsoletas
  idleTimeout: 300000 // 5 minutos
};

// Crear el pool de conexiones
const pool = mysql.createPool(config);

// Interceptar nuevas conexiones para establecer la zona horaria en UTC
// Esto garantiza que NOW() y CURRENT_TIMESTAMP usen UTC independientemente del servidor
pool.on('connection', (connection) => {
  connection.query("SET time_zone = '+00:00'");
});

// Verificar la conexión de base de datos
async function testConnection() {
  let testConnection;
  try {
    testConnection = await pool.getConnection();
    console.log('✅ Conexión a la base de datos establecida correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al conectar con la base de datos:', error.message);
    console.error('Configuración de conexión (sin contraseña):', {
      host: config.host,
      port: config.port,
      user: config.user,
      database: config.database
    });
    return false;
  } finally {
    if (testConnection) {
      testConnection.release();
    }
  }
}

// Ejecutar prueba de conexión
testConnection()
  .then(success => {
    if (!success) {
      console.error('⚠️ La aplicación podría no funcionar correctamente debido a problemas de conexión con la base de datos');
    }
  })
  .catch(err => {
    console.error('Error inesperado al probar la conexión:', err);
  });

module.exports = pool; 